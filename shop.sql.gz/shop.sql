-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 01 2020 г., 11:49
-- Версия сервера: 5.6.43
-- Версия PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `good_id` varchar(255) NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `client_info`
--

CREATE TABLE `client_info` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `time_order` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `phone` varchar(30) NOT NULL,
  `address` varchar(255) NOT NULL,
  `total_price` int(255) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `feedbacks`
--

CREATE TABLE `feedbacks` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `text` text NOT NULL,
  `date_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `feedbacks`
--

INSERT INTO `feedbacks` (`id`, `name`, `text`, `date_create`) VALUES
(3, 'Иван', 'Хорошо', '2020-11-16 09:35:36'),
(6, 'Соня Чернова', 'ffff', '2020-11-16 12:03:05'),
(7, 'Сергей', 'авлодыадовылоыа', '2020-11-16 12:28:48'),
(8, 'Ирина', 'ааыыыыы', '2020-11-16 12:28:57'),
(9, 'Степан', 'рвчпвыпвп', '2020-11-16 12:29:05'),
(10, 'Петя', 'ваываывавыа', '2020-11-17 14:03:58');

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `price` int(11) NOT NULL,
  `small_img` varchar(50) NOT NULL,
  `big_img` varchar(50) NOT NULL,
  `short_desc` text NOT NULL,
  `long_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `name`, `price`, `small_img`, `big_img`, `short_desc`, `long_desc`) VALUES
(1, 'Суккуленты', 349, '../public/img/small/succulent.jpg', '../public/img/big/succulent.jpg', 'Комнатное растение в горшке, 6 см', 'Растет в засушливых регионах по всему миру.\r\nПростое в уходе растение.\r\nИдеальное растение для офиса.\r\nЭто растение чувствительно к холодной воде и недостаточному поливу, что может выражаться в опадании листьев.'),
(2, 'Хамедорея Элеганс', 129, '../public/img/small/hamedoreya-elegans.jpg', '../public/img/big/hamedoreya-elegans.jpg', 'Растение в горшке, Хамедорея изящная, 9 см', 'Для использования в помещении.\r\nРазмещать в освещенном месте, избегая воздействия прямых солнечных лучей.Умеренный полив. '),
(3, 'Каллуна', 299, '../public/img/small/calluna.jpg', '../public/img/big/calluna.jpg', 'Растение в горшке, разные цвета, 13 см', 'Украсьте дом растениями в подходящих для вашего интерьера кашпо.\r\nОбласть естественного распространения: Европа. Для использования вне помещения.\r\nРазмещать в освещенном месте, избегая воздействия прямых солнечных лучей.'),
(4, 'Фикус Бенджамина', 499, '../public/img/small/ficus.jpg', '../public/img/big/ficus.jpg', 'Растение в горшке, Фикус Бенджамина \"Наташа\", 12 см', 'Область естественного распространения: Юго-Восточная Азия, Австралия и Африка.\r\nБыстрый рост.\r\nЭто растение чувствительно к сквознякам.\r\nРастение чувствительно к перемещениям.\r\nРастение чувствительно к недостатку света и перемещениям, что может выражаться в опадании листьев.'),
(5, 'Дипсис Желтоватый', 2999, '../public/img/small/dypsis.jpg', '../public/img/big/dypsis.jpg', 'Растение в горшке, Хризалидокарпус желтоватый, 24 см', 'Область естественного распространения: Мадагаскар.\r\nИдеальное растение для офиса.\r\nЭто растение чувствительно к сквознякам. Для использования в помещении.\r\nРазмещать в освещенном месте, избегая воздействия прямых солнечных лучей.'),
(6, 'Алоэ Вера', 349, '../public/img/small/aloe-vera.jpg', '../public/img/big/aloe-vera.jpg', 'Растение в горшке, Алоэ, 12 см', 'Область естественного распространения: Южная Африка.\r\nПростое в уходе растение.\r\nМедленный рост. Предпочитает теплую среду.\r\nДля использования в помещении.\r\nРазмещать в хорошо освещенном солнечном месте.'),
(7, 'Фаленопсис', 389, '../public/img/small/1606397215.jpg', '../public/img/big/1606397215.jpg', 'Растение в горшке, 12 см', 'Область естественного распространения: Азия.\r\nЭто растение чувствительно к сквознякам.\r\nЭто растение чувствительно к перепадам температуры.\r\nЭто растение чувствительно к избыточному поливу. Излишняя влага может ограничить доступ кислорода к корням, что вызовет повреждения растения.'),
(9, 'цветок', 389, '../public/img/small/1606397034.jpg', '../public/img/big/1606397163.jpg', 'цветок', 'лодвполдвплодполдвы апдыжлвподыпоыждпо');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `good_id` int(11) NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `pass`, `email`, `role`) VALUES
(1, 'admin', 'kjlgsjklg755827ccb0eea8a706c4c34a16891f84e7bkjlgsjklg755', 'admin@admin.ru', 1),
(3, 'sonya', 'kjlgsjklg755827ccb0eea8a706c4c34a16891f84e7bkjlgsjklg755', 'sonya@sonya.ru', 0),
(9, 'ivan', 'kjlgsjklg755827ccb0eea8a706c4c34a16891f84e7bkjlgsjklg755', 'ivan@ivan.ru', 0),
(10, 'stepan', 'kjlgsjklg755827ccb0eea8a706c4c34a16891f84e7bkjlgsjklg755', 'stepan@stepan.ru', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `client_info`
--
ALTER TABLE `client_info`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `client_info`
--
ALTER TABLE `client_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
